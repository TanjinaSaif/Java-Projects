import java.util.Scanner;

public class Application_Class {
    public static void main(String[] args) {
        UapCse myUap = new UapCse(null);
        Scanner s = new Scanner(System.in);

        System.out.println("1.Add New Employee.");
        System.out.println("2.Display your Salary.");
        System.out.println("3.Increase Salary.");
        System.out.println("4.Display an Employees Info.");
        System.out.println("5.Display List of Employees");
        System.out.println("6.Exit");

        while (true) {
            int op;
            op = s.nextInt();
            if (op == 1) {
                String nm, id, des;
                double b;
                nm = s.next();
                id = s.next();
                des = s.next();
                b = s.nextDouble();
                myUap.addNewEmployee(nm, id, des, b);
            }
            if (op == 2) {
                String id;
                id = s.next();
                myUap.getSalary(id);
            }
            if (op == 3) {
                String id;
                double amt;
                id = s.next();
                amt = s.nextDouble();
                myUap.increaseSalary(id, amt);
            }
            if (op == 4) {
                String id;
                id = s.next();
                myUap.display(id);
            }
            if (op == 5) {
                myUap.display();
            }
            if (op == 6) {
                break;
            }


        }
    }
}


