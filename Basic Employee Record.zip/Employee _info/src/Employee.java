public class Employee {
    private String name,id,designation;
    private double salary;
    public Employee(String name,String id,String designation,double salary){
        this.name = name;
        this.id = id;
        this.designation = designation;
        this.salary = salary;
    }
    void increaseSalary(double amt){
        salary += amt;
    }
    String getId(){
        return id;
    }
    double getSalary(){
        return salary;
    }
    void display(){
        System.out.println("Name: "+name+" ID:"+id+" Designation:"+designation+" Salary: "+salary);
    }
}
