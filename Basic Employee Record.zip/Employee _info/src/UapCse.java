import java.util.ArrayList;

public class UapCse {
    String name;
    ArrayList<Employee> employees;

    public UapCse(String name) {
        this.name = name;
        employees = new ArrayList<Employee>(); //instantiate//
    }

    private void addNewEmployee(Employee e) {
        employees.add(e);
    }

    public void addNewEmployee(String nm, String id, String des, double sal) {
        Employee em = new Employee(nm, id, des, sal);
        addNewEmployee(em);
    }

    private Employee findEmployee(String id) {
        for (int i = 0; i < employees.size(); i++) {
            Employee em = employees.get(i);
            if (id.equals(em.getId())) {
                return employees.get(i);
            }
        }
        return null;
    }

    public void increaseSalary(String id, double amt) {
        Employee e;
        e = findEmployee(id);
        if (e != null) {
            e.increaseSalary(amt);
        } else {
            System.out.println("Employee not found");
        }
    }

    double getSalary(String id) {
        Employee e;
        e = findEmployee(id);
        return e.getSalary();

    }
    void display() {

        for (int i = 0; i < employees.size(); i++) {
            Employee e = employees.get(i);
            e.display();
        }
    }
        public void display(String id) {
         Employee e ;
         e = findEmployee(id);
         e.display();
    }
    }


