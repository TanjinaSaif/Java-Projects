import java.util.Random;

public class BankAccount {
    private String memberName;
    private String accNumber;
    private double accountBalance;

    public BankAccount(String memberName,double accountBalance){
        this.memberName = memberName;
        this.accountBalance = accountBalance;
        Random r = new Random();
        String num = 10000 + r.nextInt(89999) + "";
        accNumber = num;
    }
    void deposit(double depAmount){
        accountBalance += depAmount;
    }
    void withdraw(double withAmount){
        if(accountBalance>=withAmount){
            accountBalance-= withAmount;
        }
        else{
            System.out.println("Sorry,Not Enough Balance!");
        }
    }
    String getAccNum(){
        return accNumber;
    }
    double getBalance(){
        return  accountBalance;
    }
    void display(){
        System.out.println("Name:"+ memberName+" Account Number: "+ accNumber+ " Balance: "+accountBalance);
    }
}
