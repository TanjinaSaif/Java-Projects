import java.util.Scanner;

public class BankApp {
    public static void main(String[] args) {
        Bank bank = new Bank(null);
        Scanner s = new Scanner(System.in);

        System.out.println("1.Create New Account.");
        System.out.println("2.Deposit Money.");
        System.out.println("3.Withdraw Money.");
        System.out.println("4.Display a Account.");
        System.out.println("5.Display All Accounts");
        System.out.println("6.Exit");

        while (true) {
            int op;
            op = s.nextInt();

            if (op == 1) {
                String name;
                double balance;
                name = s.next();
                balance = s.nextDouble();
                bank.addAccount(name, balance);
            }
            if (op == 2) {
                String accountNum;
                double amount;
                accountNum = s.next();
                amount = s.nextDouble();
                bank.deposit(accountNum, amount);
            }
            if (op == 3) {
                String accountNum;
                double amount;
                accountNum = s.next();
                amount = s.nextDouble();
                bank.withdraw(accountNum, amount);
            }
            if (op == 4) {
                String accNum;
                accNum = s.next();
                bank.display();
            }
            if (op == 5) {
                bank.display();
            }
            if (op == 0) {
                break;
            }

        }
    }
}
