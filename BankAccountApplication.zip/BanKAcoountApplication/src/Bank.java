import java.util.ArrayList;

public class Bank{
    String bankName;
    ArrayList<BankAccount> accounts ;

    public Bank(String bankName){
        this.bankName = bankName;
        accounts = new ArrayList<BankAccount>(); //instantiate//

    }
    private void addAccount(BankAccount acc){
        accounts.add(acc);
    }
    void addAccount(String name,double balance){
        BankAccount ba = new BankAccount(name,balance);
        accounts.add(ba);
    }
    BankAccount findAccount(String accNum){
        for(int i = 0; i<accounts.size(); i++){
            BankAccount ba = accounts.get(i);
            if(accNum.equals(ba.getAccNum())){
                return accounts.get(i);
            }
        }
        return null;
    }
    void deposit(String accNum,double depAmount){
       BankAccount b;
       b =  findAccount(accNum);
       if(b!=null){
           b.deposit(depAmount);
       }
       else{
           System.out.println("Account Not found!");
       }
    }
    void withdraw(String accNum,double depAmount){
        BankAccount c;
        c = findAccount(accNum);
        if(c!=null){
            c.withdraw(depAmount);
        }
        else{
            System.out.println("Account Not found!");
        }
    }
    void display() {
        for (int i = 0; i < accounts.size(); i++) {
            BankAccount b = accounts.get(i);
            b.display();
        }
    }
}
