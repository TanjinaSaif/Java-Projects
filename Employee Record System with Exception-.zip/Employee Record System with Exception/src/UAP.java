import java.util.Scanner;

public class UAP {

    public static void main(String[] args) {
        UapCse myUap = new UapCse("CSE");
        System.out.println("1.Add New Employee\n2.Salary Info of Specific Employee");
        System.out.println("3.Increase Salary of an Employee\n4.Display Details of a Specific Employee");
        System.out.println("5.Exit");

        Scanner s = new Scanner(System.in);
        while (true) {
            int op;
            op = s.nextInt();
            if (op == 1) {
                System.out.println("1.Salaried Employee\n2.Hourly Employee\n3.Commission");
                int o2;
                o2 = s.nextInt();
                if (o2 == 1) {
                    System.out.println("***SALARIED EMPLOYEE***");
                    System.out.println("Enter Your Name: ");
                    String username;
                    username = s.next();
                    System.out.println("Enter Id: ");
                    String id;
                    id = s.next();
                    System.out.println("Enter Designation: ");
                    String des;
                    des = s.next();
                    System.out.println("Enter Monthly Salary: ");
                    double sal;
                    sal = s.nextDouble();
                    myUap.addNewEmployee(username,id,des,sal);
                }

                if (o2 == 2) {
                    System.out.println("***HOURLY EMPLOYEE***");
                    System.out.println("Enter Your Name: ");
                    String username;
                    username = s.next();
                    System.out.println("Enter Id: ");
                    String id;
                    id = s.next();
                    System.out.println("Enter Designation: ");
                    String des;
                    des = s.next();
                    System.out.println("Enter Hourly Rate: ");
                    double hr;
                    hr = s.nextDouble();
                    System.out.println("Enter Hours Worked: ");
                    double hw;
                    hw = s.nextDouble();
                    myUap.addNewEmployee(username,id,des,hr,hw);
                }
                if (o2 == 2) {
                    System.out.println("***COMMISSION EMPLOYEE***");
                    System.out.println("Enter Your Name: ");
                    String username;
                    username = s.next();
                    System.out.println("Enter Id: ");
                    String id;
                    id = s.next();
                    System.out.println("Enter Designation: ");
                    String des;
                    des = s.next();
                    System.out.println("Enter Commission: ");
                    double cm;
                    cm = s.nextDouble();
                    System.out.println("Enter Sale: ");
                    double sal;
                    sal = s.nextDouble();
                    myUap.addNewEmployee(username,id,des,cm,sal);
                }
            }
            if(op ==2){
                String id;
                System.out.println("Enter employee id: ");
                id = s.next();
                myUap.getSalary(id);
                myUap.display(id);
            }
            if(op==3){
                String id;
                double amt;
                System.out.println("Enter Id: ");
                id = s.next();
                System.out.println("Enter Increase amount: ");
                amt = s.nextDouble();
                myUap.increaseSalary(id,amt);
            }
            if(op==4){
                String id;
                System.out.println("Enter Employees ID: ");
                id = s.next();
                myUap.display(id);
            }
            if(op==5){
                break;
            }
        }

    }
}






