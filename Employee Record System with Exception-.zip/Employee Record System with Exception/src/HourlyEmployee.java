public class HourlyEmployee extends Employee {
    public double hourlyRate,hourWorked;
    public HourlyEmployee(String name,String id,String designation,double hourlyRate,double hourWorked){
        super(name,id,designation);
        this.hourlyRate = hourlyRate;
        this.hourWorked = hourWorked;
    }
    @Override
    double getSalary() {
        return hourWorked*hourlyRate;
    }
    @Override
    void increaseSalary(double amt) {
        try {
            if (amt < 0) {
                throw new InvalidSalaryExeption("Increase amount must be greater than zero.");
            }
            else {
                hourlyRate+=amt;
            }
        }
        catch(Exception e){
            System.out.println(e);

        }
    }
    double getSalary(int hWorked){
        return hWorked*hourlyRate;
    }

    @Override
    void display() {
        super.display();
        System.out.println("Hourly Rate: "+hourlyRate);
    }
}
