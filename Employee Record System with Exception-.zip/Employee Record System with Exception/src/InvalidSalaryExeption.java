import java.security.InvalidParameterException;

public class InvalidSalaryExeption extends Exception {
    public InvalidSalaryExeption(String message){
        super(message);
    }
}
